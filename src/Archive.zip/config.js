var config = {};

config.api_key = 'be65fe76147759d7931718826f7db263';
config.app_id = 'amzn1.echo-sdk-ams.app.ef7b5d42-f176-4806-9ea3-6ef6d041c2aa';

module.exports = config;